{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.auth')

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HopperHost - Resetar conta</title>
    <link rel="icon" type="image/x-icon" href="https://witchhost.com/app/img/WitchHosting2.png">
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="/assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.min.css" integrity="sha256-2bAj1LMT7CXUYUwuEnqqooPb1W0Sw0uKMsqNH0HwMa4=" crossorigin="anonymous" />
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
</head>

@section('content')
<div class="row">
    </div>
</div>
<div class="login-card px-5">
  <div class="px-5">
    <br>
    <br>
    <br>
    <br>
    <h1 class="font-weight-bold text-center title mt-3">RECUPERAR SENHA</h1>
    <div class="divider w-25"></div>
    <p class="mt-2 text-muted mb-5 text-center">Digite o email da conta para receber instruções para redefinir a senha.</p>
    <span class="text-danger" id="alert" style="display: none;"></span>
                    @if (count($errors) > 0)
            <div class="alert alert-danger text-center">
                Não foi possível localizar essa conta!
            </div>
        @endif
            <label class="font-weight-bold text-muted">E-mail</label>
        <form id="resetForm" action="{{ route('auth.password') }}" method="POST">
            <div class="form-group has-feedback">
                <div class="pterodactyl-login-input">
                    <input type="email" name="email" class="form-control form-control-lg" value="{{ old('email') }}" required placeholder="@lang('strings.email')" autofocus>
                    <span class="fa fa-envelope form-control-feedback fa-lg"></span>
                    @if ($errors->has('email'))
                        <span class="help-block text-red small">
                            {{ $errors->first('email') }}
                        </span>
                    @endif
                </div>
                <div class="col-xs-offset-4 col-xs-4">
                    {!! csrf_field() !!}
                    <button type="submit" class="btn btn-secondary btn-block btn-rounded mt-3 btn btn-block g-recaptcha pterodactyl-login-button--main" @if(config('recaptcha.enabled')) data-sitekey="{{ config('recaptcha.website_key') }}" data-callback='onSubmit' @endif>@lang('Enviar email')</button>
                </div>
              </div>
           <a class="btn btn-link btn-block text-muted" href="{{ route('auth.login') }}">Acessar conta</a>
          </div>
            </div>
        </form>
    </div>
</div>
@endsection

@section('scripts')
    @parent
    @if(config('recaptcha.enabled'))
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
        <script>
        function onSubmit(token) {
            document.getElementById("resetForm").submit();
        }
        </script>
     @endif
@endsection
