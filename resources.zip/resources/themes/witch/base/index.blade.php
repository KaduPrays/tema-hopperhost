@extends('layouts.master')

@section('title')
    @lang('base.index.header')
@endsection

@section('content-header')
    <h1>@lang('base.index.header')<small>@lang('base.index.header_sub')</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('index') }}">@lang('strings.home')</a></li>
        <li class="active">@lang('strings.servers')</li>
    </ol>
@endsection

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>WitchHot - Servidores</title>
    <link rel="icon" type="image/x-icon" href="images/witchhost1.png">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.min.css" integrity="sha256-2bAj1LMT7CXUYUwuEnqqooPb1W0Sw0uKMsqNH0HwMa4=" crossorigin="anonymous" />
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
    <script src="https://kit.fontawesome.com/4cfd508d4f.js" crossorigin="anonymous"></script>
</head>

<body class="dashboard">
    <header>
        <div class="dashboard-header">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 pt-2">
                    <a href="/" class="text-white logo" style="text-decoration: none;">
                        <h2 class="text-white text-left rm-logo"> <i class="fa fa-bong"> </i> </i>HopperHost</h2>
                        </a>
                    </div>
                    <div class="col-md-8">
                        <div class="float-right">
                            <p class="text-white profile">
                                <span>
                                    Olá, {{Auth::user()->name_first}}. <br>
                                    <small>Bem-vindo de volta!</small>
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <nav class="navbar navbar-expand-lg dashboard-menu">
            <div class="container">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#conteudoNavbarSuportado" aria-controls="conteudoNavbarSuportado" aria-expanded="false" aria-label="Alterna navegação">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="/">Dashboard</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="/account">Minha conta</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="/account/security">Controle de segurança</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            @if(Auth::user()->root_admin)
                                <li>
                                    <li><a class="nav-link text-danger" href="{{ route('admin.index') }}" data-toggle="tooltip" data-placement="bottom">ADMIN</a></li>
                                </li>
                            @endif
                            <a class="nav-link text-danger" href="/auth/logout">
                                SAIR
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <main class="content">
    <div class="container">
    <h4 class="font-weight-bold"> 
    Seus servidores
    <button class="btn btn-primary float-right px-3 py-1" onclick="location.href = 'https://witchhost.com/planos'">Adquirir planos</button>
    </h4>
    <br>
    @section('content')
       <div class="box-body table-responsive no-padding container">
        <table class="table">
                    <tbody>
                        <tr>
                          <th class="text-center hidden-sm hidden-xs"> #</th>
                          <th class="text-center hidden-sm hidden-xs"> Nome</th>
                          <th class="text-center hidden-sm hidden-xs"> Node</th>
                          <th class="text-center hidden-sm hidden-xs"> Conexão</th>
                          <th class="text-center hidden-sm hidden-xs"><i class="fa fa-memory"></i> Memoria</th>
                          <th class="text-center hidden-sm hidden-xs"><i class="fa fa-microchip"></i> CPU</th>
                          <th class="text-center hidden-sm hidden-xs"><i class="fa fa-save"></i> Disco</th>
                          <th class="text-center hidden-sm hidden-xs"><i class="fa fa-dove"></i> Cargo</th>
                          <th class="text-center hidden-sm hidden-xs"> Status</th>
                        </tr> 
                        @foreach($servers as $server)
                            <tr class="dynamic-update" data-server="{{ $server->uuidShort }}">
                                <td @if(! empty($server->description)) rowspan="2" @endif><code>{{ $server->uuidShort }}</code></td>
                                <td><a href="{{ route('server.index', $server->uuidShort) }}">{{ $server->name }}</a></td>
                                <td>{{ $server->getRelation('node')->name }}</td>
                                <td class="badge"><code>{{ $server->getRelation('allocation')->alias }}:{{ $server->getRelation('allocation')->port }}</code></td>
                                <td class="text-center hidden-sm hidden-xs"><span data-action="memory">--</span> / {{ $server->memory === 0 ? '∞' : $server->memory }} MB</td>
                                <td class="text-center hidden-sm hidden-xs"><span data-action="cpu" data-cpumax="{{ $server->cpu }}">--</span> %</td>
                                <td class="text-center hidden-sm hidden-xs"><span data-action="disk">--</span> / {{ $server->disk === 0 ? '∞' : $server->disk }} MB </td>
                                <td class="text-center">
                                    @if($server->user->id === Auth::user()->id)
                                        <span class="badge badge-danger">@lang('strings.owner')</span>
                                    @elseif(Auth::user()->root_admin)
                                        <span class="badge badge-danger">@lang('strings.admin')</span>
                                    @else
                                        <span class="badge badge-danger">@lang('strings.subuser')</span>
                                    @endif
                                </td>
                                @if($server->node->maintenance_mode)
                                    <td class="text-center">
                                        <span class="label label-warning">@lang('strings.under_maintenance')</span>
                                    </td>
                                @else
                                    <td class="text-center" data-action="status">
                                        <span class="badge badge-success"><i class="fa fa-refresh fa-fw fa-spin"></i></span>
                                    </td>
                                @endif
                            </tr>
                            @if (! empty($server->description))
                                <tr class="server-description">
                                    <td colspan="8"><p class="text-muted small no-margin">{{ str_limit($server->description, 400) }}</p></td>
                                </tr>
                            @endif
                        @endforeach
                    </tbody>
                </table>
            </div>
            @if($servers->hasPages())
                <div class="box-footer">
                    <div class="col-md-12 text-center">{!! $servers->appends(['query' => Request::input('query')])->render() !!}</div>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection

@section('footer-scripts')
    @parent
    <script>
        $('tr.server-description').on('mouseenter mouseleave', function (event) {
            $(this).prev('tr').css({
                'background-color': (event.type === 'mouseenter') ? '#f5f5f5' : '',
            });
        });
    </script>
    {!! Theme::js('js/frontend/serverlist.js') !!}
@endsection

</body>
</html>