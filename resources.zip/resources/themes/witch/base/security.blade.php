<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>HopperHost - Controle de segurança</title>
<link rel="icon" type="image/x-icon" href="/images/witchhost1.png">
<link rel="stylesheet" href="/assets/css/bootstrap.min.css">
<link rel="stylesheet" href="/assets/css/owl.carousel.min.css" />
<link rel="stylesheet" href="/assets/css/styles.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.min.css" integrity="sha256-2bAj1LMT7CXUYUwuEnqqooPb1W0Sw0uKMsqNH0HwMa4=" crossorigin="anonymous" />
<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
<script src="https://kit.fontawesome.com/4cfd508d4f.js" crossorigin="anonymous"></script>
<body class="dashboard">
<header>
<div class="dashboard-header">
<div class="container">
<div class="row">
<div class="col-md-4 pt-2">
                    <a href="/" class="text-white logo" style="text-decoration: none;">
                        <h2 class="text-white text-left rm-logo"> <i class="fa fa-bong"> </i> </i>HopperHost</h2>
                        </a>
</div>
<div class="col-md-8">
<div class="float-right">
<p class="text-white profile">
                                <span>
                                    Olá, {{Auth::user()->name_first}}.<br>
                                    <small>Bem-vindo de volta!</small>
                                </span>
</p>
</div>
</div>
</div>
</div>
</div>
<nav class="navbar navbar-expand-lg dashboard-menu">
<div class="container">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#conteudoNavbarSuportado" aria-controls="conteudoNavbarSuportado" aria-expanded="false" aria-label="Alterna navegação">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
<ul class="navbar-nav mr-auto">
<li class="nav-item ">
<a class="nav-link" href="/">Dashboard</a>
</li>
<li class="nav-item ">
<a class="nav-link" href="/account">Minha conta</a>
</li>
<li class="nav-item active">
<a class="nav-link" href="/account/security">Controle de segurança</a>
</li>
</ul>
<ul class="navbar-nav">
<li class="nav-item">
<a class="nav-link text-danger" href="/auth/logout">
SAIR
</a>
</li>
</ul>
</div>
</div>
</nav>
</header>
<main class="content text-center">
<div class="container">
<div class="card">
<h5 class="mb-4 font-weight-bold">Sessões ativas</h5>
<table class="table text-center">
<thead>
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>@lang('ID')</th>
                                <th>@lang('IP')</th>
                                <th>@lang('Último uso')</th>
                                <th></th>
                            </tr>
                            @foreach($sessions as $session)
                                <tr>
                                    <td><code>{{ substr($session->id, 0, 6) }}</code></td>
                                    <td>{{ $session->ip_address }}</td>
                                    <td>{{ Carbon::createFromTimestamp($session->last_activity)->diffForHumans() }}</td>
                                    <td>
                                        <a href="{{ route('account.security.revoke', $session->id) }}">
                                            <button class="btn btn-xs btn-danger"></i> @lang('Revogar')</button>
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
</thead>
</tbody>
</table>
</div>
</div>
</div>
<script src="/themes/pterodactyl/js/frontend/2fa-modal.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.all.min.js" integrity="sha256-2RS1U6UNZdLS0Bc9z2vsvV4yLIbJNKxyA4mrx5uossk=" crossorigin="anonymous"></script>
<script src="/app/templates/site/assets/js/app.js"></script>
<script>
    $(function() {
        if(scripts instanceof Array) {
            $.each(scripts, function (index, fn) {
                if(typeof fn === 'function') fn();
            });
        }
    });
</script>
</body>
</html>