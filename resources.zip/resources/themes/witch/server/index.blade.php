{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.master')

@section('title')
    {{ trans('server.index.title', [ 'name' => $server->name]) }}
@endsection

@section('scripts')
    @parent
    {!! Theme::css('css/terminal.css') !!}
@endsection

<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>HopperHost - Servidor</title>
  <link rel="icon" type="image/x-icon" href="/images/witchhost1.png">
  <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="/assets/css/owl.carousel.min.css" />
  <link rel="stylesheet" href="/assets/css/styles.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.min.css" integrity="sha256-2bAj1LMT7CXUYUwuEnqqooPb1W0Sw0uKMsqNH0HwMa4=" crossorigin="anonymous" />
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
  <script src="https://kit.fontawesome.com/4cfd508d4f.js" crossorigin="anonymous"></script>
<body class="dashboard">
<header>

<body class="dashboard">
    <header>
        <div class="dashboard-header">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 pt-2">
                    <a href="/" class="text-white logo" style="text-decoration: none;">
                        <h2 class="text-white text-left rm-logo"> <i class="fa fa-bong"> </i> </i>HopperHost</h2>
                        </a>
                    </div>
                    <div class="col-md-8">
                        <div class="float-right">
                            <p class="text-white profile">
                                <span>
                                    Olá, {{Auth::user()->name_first}}. <br>
                                    <small>Bem-vindo de volta!</small>
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                <nav class="navbar navbar-expand-lg dashboard-menu text-center">
            <div class="container">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#conteudoNavbarSuportado" aria-controls="conteudoNavbarSuportado" aria-expanded="false" aria-label="Alterna navegação">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="{{ route('server.index', $server->uuidShort) }}"">Console do servidor</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.files.index', $server->uuidShort) }}">
                                <span>@lang('Gerenciador de arquivos')</span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.settings.sftp', $server->uuidShort) }}">
                                <span>@lang('SFTP')</span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.subusers', $server->uuidShort)}}">Sub-Usuários</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.databases.index', $server->uuidShort)}}">Banco de dados</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.settings.startup', $server->uuidShort) }}">Configurações</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            @if(Auth::user()->root_admin)
                                <li>
                                    <li><a class="nav-link text-danger" href="{{ route('admin.index') }}" data-toggle="tooltip" data-placement="bottom" title="@lang('strings.admin_cp')">ADMIN</a></li>
                                </li>
                            @endif
                            <a class="nav-link text-danger" href="/auth/logout">
                                SAIR
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <main class="content">
    <div class="container">

@section('content')
            <div class="text-center">
                <ol class="breadcrumb">
                    <li class="active">{{ $server->name }}</li>
                </ol>
                @can('power-start', $server)<button class="btn btn-success disabled" data-attr="power" data-action="start"><i class="fa fa-play"></i></button>@endcan
                @can('power-restart', $server)<button class="btn btn-warning disabled" data-attr="power" data-action="restart"><i class="fa fa-refresh"></i></button>@endcan
                @can('power-stop', $server)<button class="btn btn-danger disabled" data-attr="power" data-action="stop"><i class="fa fa-stop"></i> </button>@endcan
                @can('power-kill', $server)<button class="btn btn-danger disabled" data-attr="power" data-action="kill"><i class="fa fa-times"></i> </button>@endcan
            </div>
            <br>
<div class="row">
    <div class="col-sm-6">
        <div class="box box-primary">
            <div class="box-header with-border text-center">
                <h3 class="box-title">Uso de Memoria</h3>
            </div>
            <div class="box-body">
                <canvas id="chart_memory" style="max-height:300px;"></canvas>
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="box box-primary">
            <div class="box-header with-border text-center">
                <h3 class="box-title">Uso de CPU</h3>
            </div>
            <div class="box-body">
                <canvas id="chart_cpu" style="max-height:300px;"></canvas>
            </div>
        </div>
    </div>
</div>
            <br>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-body position-relative">
                <div id="terminal" style="width:100%;"></div>
                <div id="terminal_input" class="form-group no-margin">
                    <div class="input-group">
                        <div class="input-group-addon terminal_input--prompt">-></div>
                        <input type="text" class="form-control terminal_input--input">
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
    
    @section('footer-scripts')
    @parent
    {!! Theme::js('vendor/ansi/ansi_up.js') !!}
    {!! Theme::js('js/frontend/server.socket.js') !!}
    {!! Theme::js('vendor/mousewheel/jquery.mousewheel-min.js') !!}
    {!! Theme::js('js/frontend/console.js') !!}
    {!! Theme::js('vendor/chartjs/chart.min.js') !!}
    {!! Theme::js('vendor/jquery/date-format.min.js') !!}
    @if($server->nest->name === 'Minecraft' && $server->nest->author === 'support@pterodactyl.io')
        {!! Theme::js('js/plugins/minecraft/eula.js') !!}
    @endif
    @endsection
    </body>
</html>