{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.master')

@section('title')
    @lang('server.schedule.new.header')
@endsection

@section('scripts')
    {{-- This has to be loaded before the AdminLTE theme to avoid dropdown issues. --}}
    {!! Theme::css('vendor/select2/select2.min.css') !!}
    @parent
@endsection

@section('content-header')
    <h1>@lang('server.schedule.new.header')<small>@lang('server.schedule.new.header_sub')</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('index') }}">@lang('strings.home')</a></li>
        <li><a href="{{ route('server.index', $server->uuidShort) }}">{{ $server->name }}</a></li>
        <li><a href="{{ route('server.schedules', $server->uuidShort) }}">@lang('navigation.server.schedules')</a></li>
        <li class="active">@lang('server.schedule.new.header')</li>
    </ol>
@endsection

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HopperHost - Criar tarefa agendada</title>
    <link rel="icon" type="image/x-icon" href="https://witchhost.com/app/img/WitchHosting2.png">
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="/assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.min.css" integrity="sha256-2bAj1LMT7CXUYUwuEnqqooPb1W0Sw0uKMsqNH0HwMa4=" crossorigin="anonymous" />
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
    <script src="https://kit.fontawesome.com/4cfd508d4f.js" crossorigin="anonymous"></script>
</head>

<body class="dashboard">
    <header>
        <div class="dashboard-header">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 pt-2">
                    <a href="/" class="text-white logo" style="text-decoration: none;">
                        <h2 class="text-white text-left rm-logo"> <i class="fa fa-bong"> </i> </i>HopperHost</h2>
                        </a>
                    </div>
                    <div class="col-md-8">
                        <div class="float-right">
                            <p class="text-white profile">
                                <span>
                                    Olá, {{Auth::user()->name_first}}. <br>
                                    <small>Bem-vindo de volta!</small>
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                <nav class="navbar navbar-expand-lg dashboard-menu text-center">
            <div class="container">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#conteudoNavbarSuportado" aria-controls="conteudoNavbarSuportado" aria-expanded="false" aria-label="Alterna navegação">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.index', $server->uuidShort) }}"">Console do servidor</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.files.index', $server->uuidShort) }}">
                                <span>@lang('Gerenciador de arquivos')</span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.settings.sftp', $server->uuidShort) }}">
                                <span>@lang('SFTP')</span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.subusers', $server->uuidShort)}}">Sub-Usuários</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.databases.index', $server->uuidShort)}}">Banco de dados</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="{{ route('server.settings.startup', $server->uuidShort) }}">Configurações</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            @if(Auth::user()->root_admin)
                                <li>
                                    <li><a class="nav-link text-danger" href="{{ route('admin.index') }}" data-toggle="tooltip" data-placement="bottom" title="@lang('strings.admin_cp')">ADMIN</a></li>
                                </li>
                            @endif
                            <a class="nav-link text-danger" href="/auth/logout">
                                SAIR
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    <nav class="navbar navbar-expand-lg dashboard-menu text-center">
            <div class="container">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#conteudoNavbarSuportado" aria-controls="conteudoNavbarSuportado" aria-expanded="false" aria-label="Alterna navegação">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.settings.startup', $server->uuidShort) }}"">Inicialização</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.settings.name', $server->uuidShort) }}">
                                <span>@lang('Nome do servidor')</span>
                            </a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="{{ route('server.schedules', $server->uuidShort)}}">
                                <span>@lang('Tarefas agendadas')</span>
                            </a>
                        </li>
                </div>
    </header>
    <main class="content">
    <div class="container">

@section('content')
<form action="{{ route('server.schedules.new', $server->uuidShort) }}" method="POST">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Programar tarefa agendada</h3>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="form-group col-xs-12 text-center">
                            <label class="control-label" for="scheduleName">@lang('strings.name') <span class="field-optional"></span></label>
                            <div>
                                <input type="text" name="name" id="scheduleName" class=" form-control" value="{{ old('name') }}" />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <div class="form-group">
                                <label for="scheduleDayOfWeek" class="control-label">@lang('server.schedule.day_of_week')</label>
                                <div>
                                    <select data-action="update-field" data-field="cron_day_of_week" class="form-control" multiple>
                                        <option value="0">@lang('strings.days.sun')</option>
                                        <option value="1">@lang('strings.days.mon')</option>
                                        <option value="2">@lang('strings.days.tues')</option>
                                        <option value="3">@lang('strings.days.wed')</option>
                                        <option value="4">@lang('strings.days.thurs')</option>
                                        <option value="5">@lang('strings.days.fri')</option>
                                        <option value="6">@lang('strings.days.sat')</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" id="scheduleDayOfWeek" class="form-control" name="cron_day_of_week" value="{{ old('cron_day_of_week') }}" />
                            </div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <div class="form-group">
                                <label for="scheduleDayOfMonth" class="control-label">@lang('server.schedule.day_of_month')</label>
                                <div>
                                    <select data-action="update-field" data-field="cron_day_of_month" class="form-control" multiple>
                                        @foreach(range(1, 31) as $i)
                                            <option value="{{ $i }}">{{ $i }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" id="scheduleDayOfMonth" class="form-control" name="cron_day_of_month" value="{{ old('cron_day_of_month') }}" />
                            </div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <div class="form-group col-md-12">
                                <label for="scheduleHour" class="control-label">@lang('server.schedule.hour')</label>
                                <div>
                                    <select data-action="update-field" data-field="cron_hour" class="form-control" multiple>
                                        @foreach(range(0, 23) as $i)
                                            <option value="{{ $i }}">{{ str_pad($i, 2, '0', STR_PAD_LEFT) }}:00</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <input type="text" id="scheduleHour" class="form-control" name="cron_hour" value="{{ old('cron_hour') }}" />
                            </div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <div class="form-group">
                                <label for="scheduleMinute" class="control-label">@lang('server.schedule.minute')</label>
                                <div>
                                    <select data-action="update-field" data-field="cron_minute" class="form-control" multiple>
                                        @foreach(range(0, 55) as $i)
                                            @if($i % 5 === 0)
                                                <option value="{{ $i }}">_ _:{{ str_pad($i, 2, '0', STR_PAD_LEFT) }}</option>
                                            @endif
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" id="scheduleMinute" class="form-control" name="cron_minute" value="{{ old('cron_minute') }}" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-footer with-border">
                    <p class="small text-muted no-margin-bottom">@lang('server.schedule.time_help')</p>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="col-xs-12">
        <div class="row">
            <div class="box box-primary" id="containsTaskList">
                @include('partials.schedules.task-template')
                <div class="box-footer with-border" id="taskAppendBefore">
                    <div>
                    </div>
                    <div class="pull-right text-center">
                        {!! csrf_field() !!}
                        <button type="submit" class="btn btn-sm btn-success">@lang('server.schedule.new.submit')</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
@endsection

@section('footer-scripts')
    @parent
    {!! Theme::js('js/frontend/server.socket.js') !!}
    {!! Theme::js('vendor/select2/select2.full.min.js') !!}
    {!! Theme::js('js/frontend/tasks/view-actions.js') !!}
@endsection
