<?php

return [
    'notices' => [
        'pack_updated' => 'Pack erfolgreich aktualisiert',
        'pack_deleted' => 'Pack ":name" erfolgreich gelöscht.',
        'pack_created' => 'Ein neues Pack wurde erfolgreich erstellt.',
    ],
];
