<?php

return [
    'next' => 'Siguiente &raquo;',
    'previous' => '&laquo; Previos ',
    'sidebar' => [
        'account_settings' => 'Configuración de la cuenta',
        'files' => 'Administrador de archivos',
        'manage' => 'Administrar servidor',
        'servers' => 'Tus servidores',
    ],
];
